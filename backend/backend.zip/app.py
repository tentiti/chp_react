import eventlet

eventlet.monkey_patch()

import random
from flask import (
    Flask,
    request,
    jsonify,
    send_from_directory,
    render_template,
    url_for,
    abort,
    send_file,
)
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from werkzeug.utils import secure_filename
from flask_socketio import SocketIO, emit
import os
import uuid
from datetime import datetime

# import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageSequence
import eventlet

# 필요한 경우 이벤트렛 패치

app = Flask(__name__, static_folder="../frontend/build", static_url_path="")
CORS(app, resources={r"/*": {"origins": "*"}})  # 혹은 특정 도메인을 설정

app.config["UPLOAD_FOLDER"] = os.path.join(os.path.dirname(__file__), "uploads")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///postcard.db"
db = SQLAlchemy(app)


class Postcard(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    gif_name = db.Column(db.String(120), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    comment = db.Column(db.String(500), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    number = db.Column(db.String(50), nullable=True)

    def __repr__(self):
        return f"<Postcard {self.name}>"


socketio = SocketIO(app)

if not os.path.exists(app.config["UPLOAD_FOLDER"]):
    os.makedirs(app.config["UPLOAD_FOLDER"])


@app.context_processor
def override_url_for():
    return dict(
        url_for=lambda endpoint, **values: url_for(endpoint, _scheme="https", **values)
    )


with app.app_context():
    db.create_all()


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve(path):
    if path != "" and os.path.exists(app.static_folder + "/" + path):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, "index.html")


@app.route("/api/upload", methods=["POST"])
def upload_file():
    print("uploading..")

    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    # 원본 파일 저장
    filename = secure_filename(file.filename)
    file_ext = os.path.splitext(filename)[1]
    unique_filename = str(uuid.uuid4()) + file_ext
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], unique_filename)
    file.save(file_path)

    # 첫 프레임 추출하여 PNG로 저장
    if file_ext.lower() == ".gif":
        try:
            gif = Image.open(file_path)
            preselected_frames = [
                13,
                48,
                67,
                90,
                115,
                161,
                186,
                261,
                331,
                362,
                381,
                398,
                422,
            ]

            # 배열에서 랜덤하게 하나의 프레임 선택
            random_frame = random.choice(preselected_frames)
            gif.seek(random_frame)  # 랜덤 프레임으로 이동

            print("chose frame:", random_frame)

            still_filename = str(uuid.uuid4()) + ".webp"
            still_file_path = os.path.join(app.config["UPLOAD_FOLDER"], still_filename)

            # 첫 프레임을 PNG로 저장
            gif.save(still_file_path, "WEBP")
        except Exception as e:
            return jsonify({"error": f"Failed to process GIF: {str(e)}"}), 500
    else:
        return jsonify({"error": "Uploaded file is not a GIF"}), 400

    print(f"Original GIF filename: {unique_filename}")
    print(f"First frame PNG filename: {still_filename}")

    return jsonify({"filename": unique_filename, "stillfilename": still_filename}), 200


@app.route("/api/comment", methods=["POST"])
def post_comment():
    data = request.get_json()
    video_name = data["video_name"]
    comment_text = data["comment"]
    comment_datetime = datetime.fromisoformat(data["datetime"])
    new_comment = Comment(
        video_name=video_name, comment=comment_text, datetime=comment_datetime
    )
    db.session.add(new_comment)
    db.session.commit()
    return jsonify({"message": "Comment added"}), 200


@app.route("/api/uploads/<filename>", methods=["GET"])
def get_video(filename):
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)

    # 파일이 존재하지 않을 경우 404 오류를 반환합니다.
    if not os.path.exists(file_path):
        abort(404)

    # 파일의 크기를 가져옵니다.
    file_size = os.path.getsize(file_path)

    try:
        # send_file을 사용하여 파일을 전송하며, Content-Length 헤더를 명시적으로 추가합니다.
        response = send_file(file_path, conditional=True)
        response.headers["Content-Length"] = file_size
        return response
    except Exception as e:
        print(f"Error sending file: {e}")
        return "Error sending file", 500


# 이미지 저장 폴더 경로 설정
app.config["IMAGE_UPLOAD_FOLDER"] = os.path.join(
    os.path.dirname(__file__), "imageuploads"
)

if not os.path.exists(app.config["IMAGE_UPLOAD_FOLDER"]):
    os.makedirs(app.config["IMAGE_UPLOAD_FOLDER"])

# 배경 색상 설정 (number 값에 따라 결정)
BACKGROUND_COLORS = {
    2: (229, 224, 157),  # Red
    1: (188, 186, 191),  # Green
    3: (102, 167, 178),  # Blue
}


@app.route("/api/submit-postcard", methods=["POST"])
def submit_postcard():
    try:
        # JSON 데이터 파싱
        data = request.get_json()

        gif_name = data.get("gifName")
        name = data.get("name")
        comment = data.get("comment")
        timestamp = data.get("timestamp")
        number = data.get("selectedBackground")

        # 파일 이름만 추출하여 사용
        gif_filename = os.path.basename(gif_name)

        # Postcard 객체 생성 및 데이터베이스에 저장
        new_postcard = Postcard(
            gif_name=gif_filename,
            name=name,
            comment=comment,
            timestamp=datetime.fromisoformat(timestamp),
            number=number,
        )
        db.session.add(new_postcard)
        db.session.commit()

        # 랜덤 프레임 추출 및 PNG 저장
        gif_path = os.path.join(app.config["UPLOAD_FOLDER"], gif_filename)
        with Image.open(gif_path) as gif:
            frames = [frame.convert("RGBA") for frame in ImageSequence.Iterator(gif)]
            random_frame = random.choice(frames)
            print("***************", number)

            # 이미지 자르기 (중앙을 기준으로 이미지 크기의 20%를 잘라냄)
            width, height = random_frame.size
            crop_margin_width = int(width * 0.12)  # 양쪽에서 10%씩 잘라냄
            crop_margin_height = int(height * 0.12)  # 위아래에서 10%씩 잘라냄

            left = crop_margin_width
            upper = crop_margin_height
            right = width - crop_margin_width
            lower = height - crop_margin_height

            # 이미지를 자른다 (이미지를 잘라서 확대된 것처럼 보이게 만듦)
            random_frame = random_frame.crop((left, upper, right, lower))

            # 원 그리기 (이미지를 꽉 채우는 원)
            if number in BACKGROUND_COLORS:
                # 원을 먼저 그리기 위한 새로운 레이어 생성
                overlay = Image.new("RGBA", random_frame.size)
                draw = ImageDraw.Draw(overlay)
                width, height = random_frame.size

                # 반지름을 이미지 크기의 3분의 2로 설정
                radius = min(width, height) * (2 / 3) / 1.9
                center = (width // 2, height // 2)
                color = BACKGROUND_COLORS[number] + (255,)  # 불투명한 색상으로 설정
                draw.ellipse(
                    [
                        center[0] - radius,
                        center[1] - radius,
                        center[0] + radius,
                        center[1] + radius,
                    ],
                    fill=color,
                )

                # 원을 그린 레이어를 프레임 위에 합성
            combined = Image.alpha_composite(overlay, random_frame)
            random_frame = combined

            # PNG로 저장 (new_postcard.id.png) - RGBA 모드 유지
            png_filename = os.path.splitext(gif_filename)[0] + ".png"
            png_path = os.path.join(app.config["UPLOAD_FOLDER"], png_filename)
            random_frame.save(png_path, format="PNG")

        # 응답 반환
        return (
            jsonify(
                {"message": "Postcard submitted successfully", "id": new_postcard.id}
            ),
            200,
        )

    except Exception as e:
        # 오류 발생 시 오류 메시지와 함께 500 응답 반환
        print(f"Error: {e}")
        return jsonify({"error": "Failed to submit postcard"}), 500


@app.route("/api/postcard/<int:id>", methods=["GET"])
def get_postcard(id):
    try:
        postcard = Postcard.query.get_or_404(id)
        print(postcard.gif_name, id)
        return (
            jsonify(
                {
                    "id": postcard.id,
                    "gif_name": postcard.gif_name,
                    "png_name": postcard.gif_name.replace(".gif", ".png"),
                    "name": postcard.name,
                    "comment": postcard.comment,
                    "timestamp": postcard.timestamp.strftime("%Y년 %m월 %d일에 함께한 ")
                    + f"{postcard.id}번째 춤",
                    "number": postcard.number,
                }
            ),
            200,
        )

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": "Postcard not found"}), 404


@app.route("/api/postcards", methods=["GET"])
def get_postcards():
    try:
        # 모든 Postcard 데이터를 데이터베이스에서 가져옵니다.
        postcards = Postcard.query.order_by(Postcard.timestamp.desc()).all()
        # 각 Postcard 객체를 JSON 형태로 변환하여 응답합니다.
        postcards_data = [
            {
                "id": postcard.id,
                "gif_name": postcard.gif_name,
                # .gif을 .png로 변환
                "png_name": postcard.gif_name.replace(".gif", ".png"),
                "name": postcard.name,
                "comment": postcard.comment,
                "timestamp": postcard.timestamp.strftime("%Y년 %m월 %d일에 함께한 ")
                + "{postcard.id}번째 춤",
                "number": postcard.number,
            }
            for postcard in postcards
        ]

        return jsonify(postcards_data), 200

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": "Failed to fetch postcards"}), 500


if __name__ == "__main__":
    socketio.run(
        app,
        debug=True,
        host="0.0.0.0",
        port=8000,
        keyfile="/Users/hyungyulee/chp_react/certs/server.key",
        certfile="/Users/hyungyulee/chp_react/certs/server.crt",
    )
